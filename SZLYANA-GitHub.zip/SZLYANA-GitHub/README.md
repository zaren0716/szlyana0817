# SZLYANA — Our Little Study Space

A single-file, purple-and-pink study website. The main application is in `index.html`.

## Run locally

1. Download or extract this project.
2. Open `index.html` in a modern browser.
3. For best results, use the latest version of Chrome, Edge, or Firefox and keep an internet connection available for the document-reading libraries loaded from CDNs.

## Publish with GitHub Pages

1. Create a GitHub repository (for example, `szlyana`).
2. Upload `index.html`, `README.md`, and `.nojekyll` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site. Your website link will appear in the Pages settings.

## Important notes

- This package is a static GitHub Pages website. GitHub Pages does not run a private backend or securely hide API keys.
- Study data is saved in the current browser. It does not automatically sync between devices or between you and another user.
- The file-study tools in this version use browser-side text extraction and local question/material generation. They do **not** call Gemini or another AI service, and generated content should not be described as a live AI response.
- Some document-reading libraries are loaded from public CDNs, so those formats need an internet connection.
- This version currently enforces a 20 MB file-size limit in the file extractor. Removing the limit alone would not guarantee unlimited uploads; browser memory and supported file parsing still apply.
- A shared GitHub Pages URL is public to anyone who has the link. It is not private access control. Do not put private passwords, API keys, or sensitive study files in the repository.

## Project contents

- `index.html` — complete website (HTML, CSS, and JavaScript)
- `README.md` — setup and deployment instructions
- `.nojekyll` — tells GitHub Pages to publish the files as-is
